﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Caixa_Negra
{
	public class Buscador
	{
		public static bool buscar(int paramInt, int[] paramArrayOfInt)
		{
			int i = 0;
			do
			{
				if (paramInt == paramArrayOfInt[i])
				{
					return true;
				}
				i++;
			} while (i < paramArrayOfInt.Length - 1);
			return false;
		}
	}

	//	Prova 1: busca un element que no estigui a l’array.
	//  Prova 2: busca un element que hi sigui, més o menys, al mig de l’array.
	//  Prova 3: busca l’element que està a la última posició de l’array.
	//  Prova 4: busca l’element que està a la primera posició de l’array.
	//	Prova 5: busca l’element d’un array que només contingui un element.
	//	Prova 6: busca un element d’un array que està buit.

	class ProvaBuscador
	{
		static void Main(string[] args)
		{

		}
	}
}
