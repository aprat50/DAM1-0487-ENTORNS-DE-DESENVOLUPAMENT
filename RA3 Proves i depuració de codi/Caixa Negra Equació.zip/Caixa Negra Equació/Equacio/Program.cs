﻿using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Caixa_Negra_Equacio
{
    class Equaciodesegongrau
    {
        // a X2 + b X + c = 0 
        public static double[] Calcula(int a, int b, int c)
        {
            double[] resultat;
			
			double arrelPositiva = (-b+(Math.Sqrt(Math.Pow(b,2)-4*a*c)))/(2*a);
			double arrelNegativa = (-b-(Math.Sqrt(Math.Pow(b,2)-4*a*c)))/(2*a);

            if (arrelPositiva.ToString() == "NaN" || arrelNegativa.ToString() == "NaN")
            {
                resultat = new double[0];
            }
            else if (arrelNegativa == arrelPositiva)
            {
                resultat = new double[1];
                resultat[0] = arrelPositiva;
            }
            else
            {
                resultat = new double[2];
			    resultat[0]= arrelNegativa;
			    resultat[0]= arrelPositiva;
                }
            return resultat;
        }
        
    }
    class EquaciodesegongrauTest
    {
        static void Main(string[] args)
        {

        }
    }

    
}